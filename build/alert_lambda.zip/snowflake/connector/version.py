# Update this for the versions
# Don't change the fourth version number from None
VERSION = (4, 8, 1, None)
